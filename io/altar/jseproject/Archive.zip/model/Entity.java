package io.altar.jseproject.model;

public class Entity {

		private Integer entityId;
		
		public Integer getEntityId(){
	
		
		return entityId;
		}
		
		public void setEntityId(int entityId){
			this.entityId = entityId;
		}

		
}