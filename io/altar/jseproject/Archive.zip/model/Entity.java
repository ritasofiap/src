package io.altar.jseproject.model;

public class Entity {

		private long entityId;
		
		public long getEntityId(){
	
		
		return entityId;
		}
		
		public void setEntityId(long entityId){
			this.entityId = entityId;
		}

		
}