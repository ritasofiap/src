package io.altar.jseproject.test;

import java.util.Scanner;

public class Scan {
	public static void scanner(){
	Scanner scanner= new Scanner(System.in);
	}
}
