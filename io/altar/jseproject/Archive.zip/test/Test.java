package io.altar.jseproject.test;

import io.altar.jseproject.textinterface.TextInterface;

public class Test {

	public static void main(String[] args) {
		TextInterface.welcome();

	}

}