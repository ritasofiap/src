package io.altar.jseproject.model;

public class Entity {

		protected Integer entityId;
		
		public Integer getEntityId(){
	
			return entityId;
		}
		
		public void setEntityId(int entityId){
			this.entityId = entityId;
		}

		
}