package io.altar.jseproject.test;

import java.util.Scanner;

public class Scan {
	
	public static void scanner(){
		
	Scanner s = new Scanner(System.in);
	int input = s.nextInt();
	s.close();
	
	}
}
